import React from 'react'

const Brands = () => {
  return (
    <div>Brands</div>
  )
}

export default Brands