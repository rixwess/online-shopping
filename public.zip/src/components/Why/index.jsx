import React from "react"
import styled from "styled-components"

const Text = styled("h1")`
  color: black;
  margin-top: 100px;
  margin-left: 700px;
`

const Why = () => {
  return (
    <Text>
      <h2>Why choose Selfie?</h2>
    </Text>
  )
}

export default Why
